
# Stochastic-Inference-Engine

A Python framework for stochastic simulation, parameter
calibration, statistical evaluation, and model comparison.

**Status:** Alpha (v0.1.0)

## Overview

Stochastic-Inference-Engine provides tools for simulating
stochastic processes, estimating model parameters from
observations, and comparing statistical models.

## Features

### Stochastic simulation
- Geometric Brownian Motion (GBM)
- Euler-Maruyama integration for scalar Itô SDEs
- Additive jump diffusion
- Merton asset-price jump diffusion

### Monte Carlo methods
- Standard Monte Carlo integration
- Antithetic variates
- Importance sampling

### MCMC
- 1D Ising model with Metropolis and Gibbs updates
- 2D random-walk Metropolis sampling
- Autocorrelation and basic effective sample size diagnostics

### Synthetic financial data
- Reproducible price-path generation
- Logarithmic and simple returns
- Terminal distribution statistics
- Annualized volatility estimates

### Parameter calibration
- Closed-form maximum likelihood estimation for GBM
- Numerical maximum likelihood estimation for Merton
- Log-likelihood, AIC, and BIC

### Statistical evaluation
- Descriptive return statistics
- Autocorrelation
- Historical log-loss Value at Risk
- Historical log-loss Expected Shortfall
- Maximum drawdown
- Kolmogorov-Smirnov and Wasserstein distances

### Model comparison
- Chronological train/test splitting
- Held-out log-likelihood evaluation
- Model ranking by average test log-likelihood

## Requirements

- Python 3.10 or newer
- NumPy
- SciPy

## Installation

Clone the repository and install it in editable mode:

```bash
git clone https://github.com/RatChakraborty/StochasticInferenceEngine.git
cd StochasticInferenceEngine
python -m pip install -e ".[dev]"
```

For a regular installation from the local repository:

```bash
python -m pip install .
```

## Quick start

### Simulate geometric Brownian motion

```python
from stochastic_inference_engine import (
    GeometricBrownianMotion,
    SimulationConfig,
    SyntheticDataGenerator,
)

model = GeometricBrownianMotion(
    x0=100.0,
    mu=0.08,
    sigma=0.20,
)

config = SimulationConfig(
    horizon=1.0,
    steps=252,
    paths=1000,
    seed=42,
)

dataset = SyntheticDataGenerator.generate(
    model, config
)

print(dataset.prices.shape)
print(dataset.log_returns.shape)
print(dataset.terminal_summary())
```

### Calibrate a GBM model

```python
from stochastic_inference_engine import GBMCalibrator

result = GBMCalibrator.fit(
    dataset.log_returns,
    dt=dataset.dt,
)

print(result.parameters)
print(result.log_likelihood)
print(result.aic)
print(result.bic)
```

### Evaluate simulated returns

```python
from stochastic_inference_engine import (
    StatisticalEvaluator,
    RiskEvaluator,
)

statistics = StatisticalEvaluator.summarize(
    dataset.log_returns
)

var_95 = RiskEvaluator.value_at_risk(
    dataset.log_returns,
    confidence=0.95,
)

es_95 = RiskEvaluator.expected_shortfall(
    dataset.log_returns,
    confidence=0.95,
)

print(statistics)
print("95% log-loss VaR:", var_95)
print("95% log-loss ES:", es_95)
```

### Compare stochastic models

```python
from stochastic_inference_engine import ModelComparator

# Model comparison currently accepts a single
# chronological return series.
returns = dataset.log_returns[:, 0]

comparison = ModelComparator.compare(
    returns,
    dt=dataset.dt,
    models=("gbm", "merton"),
    merton_n_starts=3,
    merton_seed=42,
)

print("Best model:", comparison.best_model)

for score in comparison.ranking():
    print(
        score.model_name,
        score.test_average_log_likelihood,
    )
```

## Running tests

Install the development dependencies:

```bash
python -m pip install -e ".[dev]"
```

Run the full test suite:

```bash
python -m pytest tests/ -v
```

## Current limitations

- Stochastic differential equation integration currently
  focuses on scalar processes.
- Merton calibration is numerical and may be sensitive to
  initialization, sample size, and parameter identifiability.
- Model comparison currently uses a single chronological
  train/test split.
- MCMC diagnostics are basic and do not replace modern
  multi-chain convergence analysis.
- Risk metrics operate on logarithmic losses rather than
  directly on percentage portfolio losses.

## Development roadmap

Planned improvements include:

- Numerical robustness and stronger validation
- Analytical moments and distribution functions
- Ornstein-Uhlenbeck and CIR processes
- Additional stochastic integration methods
- Stochastic volatility models
- Expanded model calibration and validation
- External accuracy and performance benchmarks

## License

MIT. See the LICENSE file.
